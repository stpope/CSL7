var structswig__const__info =
[
    [ "type", "structswig__const__info.html#ae8bbc99e1cda11f24e306365cbf33893", null ],
    [ "name", "structswig__const__info.html#a0e22becc2b5b8fb084626b84c9524627", null ],
    [ "lvalue", "structswig__const__info.html#af142e4c21ad4fe61f6c2624bff034583", null ],
    [ "dvalue", "structswig__const__info.html#a74e477f1dbf515bcb7e2ef07a1d34c35", null ],
    [ "pvalue", "structswig__const__info.html#abbc43512c364bff11fac5961c1155090", null ],
    [ "ptype", "structswig__const__info.html#aedd46d173c5b5ed4ee60ad5660233557", null ]
];