var structswig__varlinkobject =
[
    [ "vars", "structswig__varlinkobject.html#a8cf96d999cdf0b28a0e90ccb6804c9bd", null ]
];