var classcsl_1_1_logic_error =
[
    [ "LogicError", "classcsl_1_1_logic_error.html#acbe532e31b7c05c38b6d6dd98eed7b36", null ],
    [ "what", "classcsl_1_1_logic_error.html#a0e968a3a52169139fcc18dea203a84af", null ],
    [ "mMessage", "classcsl_1_1_logic_error.html#a82f57e285f07ca934823977ed3d364e3", null ]
];