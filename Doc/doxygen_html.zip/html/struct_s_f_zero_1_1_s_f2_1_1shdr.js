var struct_s_f_zero_1_1_s_f2_1_1shdr =
[
    [ "ReadFrom", "struct_s_f_zero_1_1_s_f2_1_1shdr.html#a04697ec0aa809fa1936a1a2d80748494", null ],
    [ "sizeInFile", "struct_s_f_zero_1_1_s_f2_1_1shdr.html#a4e521c0795b3d94c1ef1811d164943d6", null ]
];