var _spectral_8h =
[
    [ "csl::FFT", "classcsl_1_1_f_f_t.html", "classcsl_1_1_f_f_t" ],
    [ "csl::IFFT", "classcsl_1_1_i_f_f_t.html", "classcsl_1_1_i_f_f_t" ],
    [ "csl::Vocoder", "classcsl_1_1_vocoder.html", "classcsl_1_1_vocoder" ]
];