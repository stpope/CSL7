var _ambisonic_utilities_8cpp =
[
    [ "PYTHAG", "_ambisonic_utilities_8cpp.html#a97cfa0a45844dfb70b87063ca392b1b0", null ],
    [ "MAX", "_ambisonic_utilities_8cpp.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "SIGN", "_ambisonic_utilities_8cpp.html#ac89d5f8a358eb8a1abdcd0fcef134f1a", null ],
    [ "at", "_ambisonic_utilities_8cpp.html#a37fcc8784e453736049a02704e1da2e2", null ],
    [ "bt", "_ambisonic_utilities_8cpp.html#a0630715fabe476d7e4b8dd8d64128daf", null ],
    [ "ct", "_ambisonic_utilities_8cpp.html#a9037f0baae8f8b8c1eb17f4648431787", null ],
    [ "maxarg1", "_ambisonic_utilities_8cpp.html#abc59d4bbc0d32bfa3f3781fcbf4e86f4", null ],
    [ "maxarg2", "_ambisonic_utilities_8cpp.html#a9a3caa54f202441d8ca46930c8a09b62", null ]
];