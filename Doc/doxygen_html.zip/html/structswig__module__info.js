var structswig__module__info =
[
    [ "types", "structswig__module__info.html#ad658c7738e9a035ef8eea865322fbf13", null ],
    [ "size", "structswig__module__info.html#aaf8907cf8509ee0464af8c9dfd909042", null ],
    [ "next", "structswig__module__info.html#ac177d150b85ab77122089acf1f06d9c6", null ],
    [ "type_initial", "structswig__module__info.html#a76c7d5b0fc10371748616d0b6c815a17", null ],
    [ "cast_initial", "structswig__module__info.html#a15f6b50a41f144afb1148fc412dc01f7", null ],
    [ "clientdata", "structswig__module__info.html#a9fb6e461fcaf14c209049adfae4e9754", null ]
];