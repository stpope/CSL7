var structswig__type__info =
[
    [ "name", "structswig__type__info.html#a90a9c6a25aa3e923978005ecbe23ad60", null ],
    [ "str", "structswig__type__info.html#abbe7cc58a083feb4329b748643324064", null ],
    [ "dcast", "structswig__type__info.html#a07df4bedf85be77b23756b531b60e0dd", null ],
    [ "cast", "structswig__type__info.html#a3ee3f7ef20e965b6c798d79723a96f9b", null ],
    [ "clientdata", "structswig__type__info.html#a19bdd65dceb89cd54befd3ded06558b7", null ],
    [ "owndata", "structswig__type__info.html#a93c25d5903cbfcb82208eea7227c32bd", null ]
];