var _spectral_proc_8h =
[
    [ "CSLComponent", "class_c_s_l_component.html", "class_c_s_l_component" ]
];