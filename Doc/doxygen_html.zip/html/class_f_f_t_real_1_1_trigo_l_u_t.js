var class_f_f_t_real_1_1_trigo_l_u_t =
[
    [ "TrigoLUT", "class_f_f_t_real_1_1_trigo_l_u_t.html#a72ce3a8c6dedb2e645ec67c2403c57a0", null ],
    [ "~TrigoLUT", "class_f_f_t_real_1_1_trigo_l_u_t.html#a1badcc873fb25be6ddb5d1c2298dcc01", null ],
    [ "get_ptr", "class_f_f_t_real_1_1_trigo_l_u_t.html#af0ab832b3973e08d728e0ad060007b62", null ],
    [ "_ptr", "class_f_f_t_real_1_1_trigo_l_u_t.html#a47d7a8e201d482a4a145178942d5ff4a", null ]
];