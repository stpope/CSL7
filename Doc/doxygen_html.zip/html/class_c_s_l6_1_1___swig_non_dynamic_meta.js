var class_c_s_l6_1_1___swig_non_dynamic_meta =
[
    [ "__setattr__", "class_c_s_l6_1_1___swig_non_dynamic_meta.html#a6827a265503e9138af6e9ad45cee660c", null ]
];