var union_s_f_zero_1_1_s_f2_1_1gen_amount_type =
[
    [ "range", "union_s_f_zero_1_1_s_f2_1_1gen_amount_type.html#a24d9019f9c3cdec3432ec1477fba105b", null ],
    [ "shortAmount", "union_s_f_zero_1_1_s_f2_1_1gen_amount_type.html#a37f27ddcd187fd4c58676ce60680e520", null ],
    [ "wordAmount", "union_s_f_zero_1_1_s_f2_1_1gen_amount_type.html#aed452eff4957e9215de9711a2304198f", null ]
];