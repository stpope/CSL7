var _f_i_r_8cpp =
[
    [ "BANDPASS", "_f_i_r_8cpp.html#a3ebfa4d7e384f53e6a37ff0d0d98627d", null ],
    [ "DIFFERENTIATOR", "_f_i_r_8cpp.html#a677e6c6816bcf472eaf8875cc8fe729d", null ],
    [ "HILBERT", "_f_i_r_8cpp.html#aff6936b3d5de51dd8968ce8a44c0176d", null ],
    [ "NEGATIVE", "_f_i_r_8cpp.html#ae8da539b402ed6856028a0a60240bbff", null ],
    [ "POSITIVE", "_f_i_r_8cpp.html#aefb7723e1092c450754ef6c07922b1bf", null ],
    [ "Pi", "_f_i_r_8cpp.html#a0c233fcb94ea9f05596b48427095806e", null ],
    [ "Pi2", "_f_i_r_8cpp.html#aa5f7ec8ff2ff24995c32143fc53005da", null ],
    [ "GRIDDENSITY", "_f_i_r_8cpp.html#a701053a83ca85d18c7e72066e97eca2e", null ],
    [ "MAXITERATIONS", "_f_i_r_8cpp.html#a988e935ee6ed10d959e44e47780ddcbf", null ],
    [ "remez", "_f_i_r_8cpp.html#a3fc5d3fe605c3a0eba5ad6b50551b137", null ],
    [ "CreateDenseGrid", "_f_i_r_8cpp.html#a67a73b492c1ead1bb1c1a0fd3b6cdbd8", null ],
    [ "InitialGuess", "_f_i_r_8cpp.html#a7fc8bdbd9516886d2d3f40438a5d8cd3", null ],
    [ "CalcParms", "_f_i_r_8cpp.html#a6f3fd3ca99a455076fdaa312f6765a65", null ],
    [ "ComputeA", "_f_i_r_8cpp.html#a90fc77f721c4d2a4698b0ea0cd9b5d96", null ],
    [ "CalcError", "_f_i_r_8cpp.html#ad55c12d5487b153eaac57c6b68af54e8", null ],
    [ "Search", "_f_i_r_8cpp.html#ad6e63be0ec56c3227b50a8928f21a7c7", null ],
    [ "FreqSample", "_f_i_r_8cpp.html#ac3c7ecbfc3a52ca6ab85b838730751a6", null ],
    [ "isFDone", "_f_i_r_8cpp.html#ab5ce4c5344cce28b662ea812c517b935", null ],
    [ "remez", "_f_i_r_8cpp.html#ae1a61c4ca5e8be0362e0c8ac39873789", null ]
];