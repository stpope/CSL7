var class_c_s_l6_1_1_filter_specification =
[
    [ "__init__", "class_c_s_l6_1_1_filter_specification.html#a0b2ad5a14d6df1caf67e8ec96bcc73c6", null ],
    [ "__repr__", "class_c_s_l6_1_1_filter_specification.html#a32cbad389011711da63abe47a899c7bf", null ],
    [ "__swig_destroy__", "class_c_s_l6_1_1_filter_specification.html#a9a3f89ad4d8e5d48af78694ea3c1620c", null ],
    [ "setFrequencies", "class_c_s_l6_1_1_filter_specification.html#ad5bb1c09ab4902d0ca222cb1476ceba9", null ],
    [ "setResponses", "class_c_s_l6_1_1_filter_specification.html#a6f33224a76a03257e95eab1c2f933062", null ],
    [ "setWeights", "class_c_s_l6_1_1_filter_specification.html#a756be30634d5aba121156fdf1e9881c1", null ],
    [ "setNumTaps", "class_c_s_l6_1_1_filter_specification.html#adf1ee8c77a3fc64b0ec11c1898d4cb3a", null ],
    [ "planFilter", "class_c_s_l6_1_1_filter_specification.html#a84e6b6f605270c7f11d2375c0f5636c7", null ],
    [ "thisown", "class_c_s_l6_1_1_filter_specification.html#a7582f26bc55723921b50eb3df3dd99c1", null ],
    [ "mNumTaps", "class_c_s_l6_1_1_filter_specification.html#ab45ec947afe2ca2e979c6b44c52a2717", null ],
    [ "mTapData", "class_c_s_l6_1_1_filter_specification.html#a019c6f1a1a08735863b7147b9548eaaa", null ],
    [ "mNumBands", "class_c_s_l6_1_1_filter_specification.html#a4c62d0f1d561bcd153d9d46d305a5642", null ],
    [ "mFrequencies", "class_c_s_l6_1_1_filter_specification.html#ac5019703d5de83fa1eb1ee882a9d574c", null ],
    [ "mResponses", "class_c_s_l6_1_1_filter_specification.html#a520223f12f735eb98e1f5d0eb2c16e06", null ],
    [ "mWeights", "class_c_s_l6_1_1_filter_specification.html#ab5059482aac160c80c04488916fdda20", null ]
];