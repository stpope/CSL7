var _v_b_a_p_8cpp =
[
    [ "Connection", "struct_connection.html", "struct_connection" ],
    [ "MAX_NUM_VBAP_TRIPLETS", "_v_b_a_p_8cpp.html#afcec86f6f7307d4cfbd5b538d57b6992", null ],
    [ "MIN_VOLUME_TO_LENGTH_RATIO", "_v_b_a_p_8cpp.html#a740c00972ee54196c68650c618a1a295", null ],
    [ "vecAngle", "_v_b_a_p_8cpp.html#a53c4e4537f9c36e7fd42435d3d007401", null ],
    [ "vectorMultiply", "_v_b_a_p_8cpp.html#ab154d53cdce4425fb4188a86f0e29987", null ]
];