var class_c_s_l6_1_1_filter =
[
    [ "__init__", "class_c_s_l6_1_1_filter.html#a52f68bfa250409b736f9ebdc35e669f2", null ],
    [ "__repr__", "class_c_s_l6_1_1_filter.html#a569927cce4dab293d73307c9c6325b86", null ],
    [ "__swig_destroy__", "class_c_s_l6_1_1_filter.html#a34aa7de6a18c094986147b0600cb77c7", null ],
    [ "clear", "class_c_s_l6_1_1_filter.html#ae7e2b84213e2d0a010a0eaa3aa765020", null ],
    [ "setupCoeffs", "class_c_s_l6_1_1_filter.html#a7ac871e4bfc234dda5236c2a76a06031", null ],
    [ "thisown", "class_c_s_l6_1_1_filter.html#abf079850ed83ae2ea96d01b4e6c36cfa", null ]
];