var hierarchy =
[
    [ "csl::Abst_FFT_W", "classcsl_1_1_abst___f_f_t___w.html", null ],
    [ "csl::Accessor", "classcsl_1_1_accessor.html", null ],
    [ "csl::AmbisonicOrder", "classcsl_1_1_ambisonic_order.html", null ],
    [ "juce::AsyncUpdater", null, [
      [ "csl::MIDIIn", "classcsl_1_1_m_i_d_i_in.html", null ]
    ] ],
    [ "AudioEffectX", null, [
      [ "csl::VSTIO", "classcsl_1_1_v_s_t_i_o.html", null ]
    ] ],
    [ "AudioIODeviceCallback", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", null ],
      [ "CSLServerComponent", "class_c_s_l_server_component.html", null ]
    ] ],
    [ "juce::AudioIODeviceCallback", null, [
      [ "AudioWaveformDisplay", "class_audio_waveform_display.html", [
        [ "AudioSpectrumDisplay", "class_audio_spectrum_display.html", null ]
      ] ],
      [ "CSLAbstComponent", "class_c_s_l_abst_component.html", [
        [ "CSLSignalComponent", "class_c_s_l_signal_component.html", null ]
      ] ],
      [ "VUMeter", "class_v_u_meter.html", null ],
      [ "csl::JUCEIO", "classcsl_1_1_j_u_c_e_i_o.html", null ]
    ] ],
    [ "math::matrix::base_mat", "structmath_1_1matrix_1_1base__mat.html", null ],
    [ "csl::BinauralSourceCache", "classcsl_1_1_binaural_source_cache.html", null ],
    [ "FFTReal::BitReversedLUT", "class_f_f_t_real_1_1_bit_reversed_l_u_t.html", null ],
    [ "csl::Buffer", "classcsl_1_1_buffer.html", [
      [ "csl::BufferCMap", "classcsl_1_1_buffer_c_map.html", null ]
    ] ],
    [ "ButtonListener", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", null ],
      [ "CSLServerComponent", "class_c_s_l_server_component.html", null ]
    ] ],
    [ "csl::Cacheable", "classcsl_1_1_cacheable.html", [
      [ "csl::CompOrCacheOscillator", "classcsl_1_1_comp_or_cache_oscillator.html", [
        [ "csl::SumOfSines", "classcsl_1_1_sum_of_sines.html", [
          [ "csl::SquareBL", "classcsl_1_1_square_b_l.html", null ]
        ] ]
      ] ]
    ] ],
    [ "csl::CGestalt", "classcsl_1_1_c_gestalt.html", null ],
    [ "csl::CMIDIMessage", "classcsl_1_1_c_m_i_d_i_message.html", null ],
    [ "csl::Comb", "classcsl_1_1_comb.html", null ],
    [ "ComboBoxListener", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ]
    ] ],
    [ "Component", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", null ],
      [ "CSLServerComponent", "class_c_s_l_server_component.html", null ]
    ] ],
    [ "juce::Component", null, [
      [ "AudioWaveformDisplay", "class_audio_waveform_display.html", null ],
      [ "CSLAbstComponent", "class_c_s_l_abst_component.html", null ],
      [ "VUMeter", "class_v_u_meter.html", null ]
    ] ],
    [ "Connection", "struct_connection.html", null ],
    [ "csl::Controllable", "classcsl_1_1_controllable.html", [
      [ "csl::Effect", "classcsl_1_1_effect.html", [
        [ "SAFliter", "class_s_a_fliter.html", null ],
        [ "csl::BinaryOp", "classcsl_1_1_binary_op.html", [
          [ "csl::AddOp", "classcsl_1_1_add_op.html", null ],
          [ "csl::MulOp", "classcsl_1_1_mul_op.html", null ],
          [ "csl::SubOp", "classcsl_1_1_sub_op.html", null ]
        ] ],
        [ "csl::Clipper", "classcsl_1_1_clipper.html", null ],
        [ "csl::Convolver", "classcsl_1_1_convolver.html", null ],
        [ "csl::Convolver2", "classcsl_1_1_convolver2.html", null ],
        [ "csl::DelayLine", "classcsl_1_1_delay_line.html", null ],
        [ "csl::DynamicVariable", "classcsl_1_1_dynamic_variable.html", null ],
        [ "csl::FFT", "classcsl_1_1_f_f_t.html", null ],
        [ "csl::FIR", "classcsl_1_1_f_i_r.html", null ],
        [ "csl::FanOut", "classcsl_1_1_fan_out.html", [
          [ "csl::Splitter", "classcsl_1_1_splitter.html", null ]
        ] ],
        [ "csl::Filter", "classcsl_1_1_filter.html", [
          [ "csl::Allpass", "classcsl_1_1_allpass.html", null ],
          [ "csl::Biquad", "classcsl_1_1_biquad.html", null ],
          [ "csl::Butter", "classcsl_1_1_butter.html", null ],
          [ "csl::Formant", "classcsl_1_1_formant.html", null ],
          [ "csl::Moog", "classcsl_1_1_moog.html", null ],
          [ "csl::Notch", "classcsl_1_1_notch.html", null ]
        ] ],
        [ "csl::Freeverb", "classcsl_1_1_freeverb.html", null ],
        [ "csl::InOut", "classcsl_1_1_in_out.html", null ],
        [ "csl::Joiner", "classcsl_1_1_joiner.html", null ],
        [ "csl::Panner", "classcsl_1_1_panner.html", [
          [ "csl::NtoMPanner", "classcsl_1_1_nto_m_panner.html", null ]
        ] ],
        [ "csl::RingBuffer", "classcsl_1_1_ring_buffer.html", null ],
        [ "csl::StereoWidth", "classcsl_1_1_stereo_width.html", null ],
        [ "csl::Stereoverb", "classcsl_1_1_stereoverb.html", null ]
      ] ],
      [ "csl::FrequencyAmount", "classcsl_1_1_frequency_amount.html", [
        [ "csl::Filter", "classcsl_1_1_filter.html", null ]
      ] ],
      [ "csl::Phased", "classcsl_1_1_phased.html", [
        [ "csl::KarplusString", "classcsl_1_1_karplus_string.html", null ],
        [ "csl::Oscillator", "classcsl_1_1_oscillator.html", [
          [ "csl::FSine", "classcsl_1_1_f_sine.html", null ],
          [ "csl::Impulse", "classcsl_1_1_impulse.html", null ],
          [ "csl::Sawtooth", "classcsl_1_1_sawtooth.html", null ],
          [ "csl::Sine", "classcsl_1_1_sine.html", [
            [ "csl::WaveShaper", "classcsl_1_1_wave_shaper.html", null ]
          ] ],
          [ "csl::Square", "classcsl_1_1_square.html", null ],
          [ "csl::WavetableOscillator", "classcsl_1_1_wavetable_oscillator.html", [
            [ "csl::Abst_SoundFile", "classcsl_1_1_abst___sound_file.html", [
              [ "csl::CASoundFile", "classcsl_1_1_c_a_sound_file.html", null ],
              [ "csl::JSoundFile", "classcsl_1_1_j_sound_file.html", null ],
              [ "csl::LSoundFile", "classcsl_1_1_l_sound_file.html", null ]
            ] ],
            [ "csl::CompOrCacheOscillator", "classcsl_1_1_comp_or_cache_oscillator.html", null ]
          ] ]
        ] ],
        [ "csl::SineAsPhased", "classcsl_1_1_sine_as_phased.html", null ],
        [ "csl::SineAsScaled", "classcsl_1_1_sine_as_scaled.html", null ]
      ] ],
      [ "csl::Scalable", "classcsl_1_1_scalable.html", [
        [ "csl::Envelope", "classcsl_1_1_envelope.html", [
          [ "csl::ADSR", "classcsl_1_1_a_d_s_r.html", null ],
          [ "csl::AR", "classcsl_1_1_a_r.html", null ],
          [ "csl::RandEnvelope", "classcsl_1_1_rand_envelope.html", null ],
          [ "csl::Triangle", "classcsl_1_1_triangle.html", null ]
        ] ],
        [ "csl::Filter", "classcsl_1_1_filter.html", null ],
        [ "csl::Freeverb", "classcsl_1_1_freeverb.html", null ],
        [ "csl::KarplusString", "classcsl_1_1_karplus_string.html", null ],
        [ "csl::Mixer", "classcsl_1_1_mixer.html", null ],
        [ "csl::Noise", "classcsl_1_1_noise.html", [
          [ "csl::PinkNoise", "classcsl_1_1_pink_noise.html", null ],
          [ "csl::WhiteNoise", "classcsl_1_1_white_noise.html", null ]
        ] ],
        [ "csl::Oscillator", "classcsl_1_1_oscillator.html", null ],
        [ "csl::Panner", "classcsl_1_1_panner.html", null ],
        [ "csl::RingBuffer", "classcsl_1_1_ring_buffer.html", null ],
        [ "csl::RingBufferTap", "classcsl_1_1_ring_buffer_tap.html", null ],
        [ "csl::SineAsScaled", "classcsl_1_1_sine_as_scaled.html", null ],
        [ "csl::SpatialSource", "classcsl_1_1_spatial_source.html", [
          [ "csl::DistanceSimulator", "classcsl_1_1_distance_simulator.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Controller", "class_controller.html", null ],
    [ "controller_str", "structcontroller__str.html", null ],
    [ "csl::CPoint", "classcsl_1_1_c_point.html", null ],
    [ "csl::CSL_MIDIMessage", "classcsl_1_1_c_s_l___m_i_d_i_message.html", null ],
    [ "csl::CSL_RS_MSG", "structcsl_1_1_c_s_l___r_s___m_s_g.html", null ],
    [ "csl::CThread", "classcsl_1_1_c_thread.html", [
      [ "csl::ThreadPthread", "classcsl_1_1_thread_pthread.html", [
        [ "csl::NullIO", "classcsl_1_1_null_i_o.html", [
          [ "csl::StdIO", "classcsl_1_1_std_i_o.html", null ]
        ] ]
      ] ]
    ] ],
    [ "csl::CVariable", "classcsl_1_1_c_variable.html", [
      [ "csl::DynamicVariable", "classcsl_1_1_dynamic_variable.html", null ],
      [ "csl::StaticVariable", "classcsl_1_1_static_variable.html", null ]
    ] ],
    [ "csl::DistanceCue", "classcsl_1_1_distance_cue.html", [
      [ "csl::AirAbsorptionCue", "classcsl_1_1_air_absorption_cue.html", null ],
      [ "csl::IntensityAttenuationCue", "classcsl_1_1_intensity_attenuation_cue.html", null ]
    ] ],
    [ "DocumentWindow", null, [
      [ "CSLWindow", "class_c_s_l_window.html", null ]
    ] ],
    [ "juce::DocumentWindow", null, [
      [ "CSLWindow", "class_c_s_l_window.html", null ]
    ] ],
    [ "exception", null, [
      [ "SocketException", "class_socket_exception.html", null ]
    ] ],
    [ "Exception", null, [
      [ "CSL6.CException", "class_c_s_l6_1_1_c_exception.html", [
        [ "CSL6.LogicError", "class_c_s_l6_1_1_logic_error.html", [
          [ "CSL6.DBError", "class_c_s_l6_1_1_d_b_error.html", null ]
        ] ],
        [ "CSL6.MemoryError", "class_c_s_l6_1_1_memory_error.html", null ],
        [ "CSL6.RunTimeError", "class_c_s_l6_1_1_run_time_error.html", null ],
        [ "CSL6.TimingError", "class_c_s_l6_1_1_timing_error.html", null ],
        [ "CSL6.ValueError", "class_c_s_l6_1_1_value_error.html", [
          [ "CSL6.DomainError", "class_c_s_l6_1_1_domain_error.html", null ],
          [ "CSL6.IOError", "class_c_s_l6_1_1_i_o_error.html", null ],
          [ "CSL6.OutOfRangeError", "class_c_s_l6_1_1_out_of_range_error.html", null ],
          [ "CSL6.ProcessingError", "class_c_s_l6_1_1_processing_error.html", null ]
        ] ]
      ] ]
    ] ],
    [ "std::exception", null, [
      [ "csl::CException", "classcsl_1_1_c_exception.html", [
        [ "csl::LogicError", "classcsl_1_1_logic_error.html", [
          [ "csl::DBError", "classcsl_1_1_d_b_error.html", null ]
        ] ],
        [ "csl::MemoryError", "classcsl_1_1_memory_error.html", null ],
        [ "csl::RunTimeError", "classcsl_1_1_run_time_error.html", null ],
        [ "csl::TimingError", "classcsl_1_1_timing_error.html", null ],
        [ "csl::ValueError", "classcsl_1_1_value_error.html", [
          [ "csl::DomainError", "classcsl_1_1_domain_error.html", null ],
          [ "csl::IOError", "classcsl_1_1_i_o_error.html", null ],
          [ "csl::OutOfRangeError", "classcsl_1_1_out_of_range_error.html", null ],
          [ "csl::ProcessingError", "classcsl_1_1_processing_error.html", null ]
        ] ]
      ] ]
    ] ],
    [ "csl::FAllpass", "classcsl_1_1_f_allpass.html", null ],
    [ "FFTReal", "class_f_f_t_real.html", null ],
    [ "csl::FilterSpecification", "classcsl_1_1_filter_specification.html", null ],
    [ "FrameStream", null, [
      [ "csl::DLine", "classcsl_1_1_d_line.html", null ]
    ] ],
    [ "SFZero::SF2::genAmountType", "union_s_f_zero_1_1_s_f2_1_1gen_amount_type.html", null ],
    [ "csl::Grain", "structcsl_1_1_grain.html", null ],
    [ "csl::GrainCloud", "classcsl_1_1_grain_cloud.html", null ],
    [ "csl::HRTF", "classcsl_1_1_h_r_t_f.html", null ],
    [ "csl::HRTFDatabase", "classcsl_1_1_h_r_t_f_database.html", null ],
    [ "SFZero::SF2::Hydra", "struct_s_f_zero_1_1_s_f2_1_1_hydra.html", null ],
    [ "SFZero::SF2::ibag", "struct_s_f_zero_1_1_s_f2_1_1ibag.html", null ],
    [ "SFZero::SF2::igen", "struct_s_f_zero_1_1_s_f2_1_1igen.html", null ],
    [ "SFZero::SF2::imod", "struct_s_f_zero_1_1_s_f2_1_1imod.html", null ],
    [ "SFZero::SF2::inst", "struct_s_f_zero_1_1_s_f2_1_1inst.html", null ],
    [ "Inst_Context", "struct_inst___context.html", null ],
    [ "csl::Interleaver", "classcsl_1_1_interleaver.html", null ],
    [ "csl::IODevice", "classcsl_1_1_i_o_device.html", null ],
    [ "SFZero::SF2::iver", "struct_s_f_zero_1_1_s_f2_1_1iver.html", null ],
    [ "juce::JUCEApplication", null, [
      [ "JUCECSLApplication", "class_j_u_c_e_c_s_l_application.html", null ]
    ] ],
    [ "JUCEApplication", null, [
      [ "JUCECSLApplication", "class_j_u_c_e_c_s_l_application.html", null ]
    ] ],
    [ "juce::Button::Listener", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLSignalComponent", "class_c_s_l_signal_component.html", null ]
    ] ],
    [ "juce::ComboBox::Listener", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLSignalComponent", "class_c_s_l_signal_component.html", null ]
    ] ],
    [ "juce::Slider::Listener", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLSignalComponent", "class_c_s_l_signal_component.html", null ]
    ] ],
    [ "logic_error", null, [
      [ "math::matrix_error", "classmath_1_1matrix__error.html", null ]
    ] ],
    [ "math::matrix", "classmath_1_1matrix.html", null ],
    [ "juce::MidiInputCallback", null, [
      [ "csl::MIDIIn", "classcsl_1_1_m_i_d_i_in.html", null ]
    ] ],
    [ "juce::MidiKeyboardStateListener", null, [
      [ "csl::MIDIIn", "classcsl_1_1_m_i_d_i_in.html", null ]
    ] ],
    [ "csl::Model", "classcsl_1_1_model.html", [
      [ "csl::IO", "classcsl_1_1_i_o.html", [
        [ "csl::AUIO", "classcsl_1_1_a_u_i_o.html", [
          [ "csl::CAIO", "classcsl_1_1_c_a_i_o.html", null ],
          [ "csl::iPhoneIO", "classcsl_1_1i_phone_i_o.html", null ]
        ] ],
        [ "csl::FileIO", "classcsl_1_1_file_i_o.html", null ],
        [ "csl::JUCEIO", "classcsl_1_1_j_u_c_e_i_o.html", null ],
        [ "csl::JackIO", "classcsl_1_1_jack_i_o.html", null ],
        [ "csl::NullIO", "classcsl_1_1_null_i_o.html", null ],
        [ "csl::PAIO", "classcsl_1_1_p_a_i_o.html", null ],
        [ "csl::RemoteIO", "classcsl_1_1_remote_i_o.html", null ],
        [ "csl::VSTIO", "classcsl_1_1_v_s_t_i_o.html", null ]
      ] ],
      [ "csl::MIDIIO", "classcsl_1_1_m_i_d_i_i_o.html", [
        [ "csl::MIDIIn", "classcsl_1_1_m_i_d_i_in.html", null ],
        [ "csl::MIDIOut", "classcsl_1_1_m_i_d_i_out.html", null ],
        [ "csl::MIDIPlayer", "classcsl_1_1_m_i_d_i_player.html", null ]
      ] ],
      [ "csl::SpeakerLayout", "classcsl_1_1_speaker_layout.html", [
        [ "csl::HeadphoneSpeakerLayout", "classcsl_1_1_headphone_speaker_layout.html", null ],
        [ "csl::StereoSpeakerLayout", "classcsl_1_1_stereo_speaker_layout.html", null ]
      ] ],
      [ "csl::UnitGenerator", "classcsl_1_1_unit_generator.html", [
        [ "SFZero::SFZVoice", "class_s_f_zero_1_1_s_f_z_voice.html", null ],
        [ "csl::AmbisonicUnitGenerator", "classcsl_1_1_ambisonic_unit_generator.html", [
          [ "csl::AmbisonicDecoder", "classcsl_1_1_ambisonic_decoder.html", null ],
          [ "csl::AmbisonicEncoder", "classcsl_1_1_ambisonic_encoder.html", null ],
          [ "csl::AmbisonicMixer", "classcsl_1_1_ambisonic_mixer.html", null ],
          [ "csl::AmbisonicRotator", "classcsl_1_1_ambisonic_rotator.html", null ]
        ] ],
        [ "csl::BlockResizer", "classcsl_1_1_block_resizer.html", null ],
        [ "csl::BufferStream", "classcsl_1_1_buffer_stream.html", null ],
        [ "csl::Effect", "classcsl_1_1_effect.html", null ],
        [ "csl::Envelope", "classcsl_1_1_envelope.html", null ],
        [ "csl::GrainPlayer", "classcsl_1_1_grain_player.html", null ],
        [ "csl::IFFT", "classcsl_1_1_i_f_f_t.html", null ],
        [ "csl::Instrument", "classcsl_1_1_instrument.html", [
          [ "csl::AdditiveInstrument", "classcsl_1_1_additive_instrument.html", null ],
          [ "csl::FMBell", "classcsl_1_1_f_m_bell.html", null ],
          [ "csl::FMInstrument", "classcsl_1_1_f_m_instrument.html", [
            [ "csl::FancyFMInstrument", "classcsl_1_1_fancy_f_m_instrument.html", null ]
          ] ],
          [ "csl::GranulatorInstrument", "classcsl_1_1_granulator_instrument.html", null ],
          [ "csl::SHARCAddInstrument", "classcsl_1_1_s_h_a_r_c_add_instrument.html", null ],
          [ "csl::SHARCAddInstrumentC", "classcsl_1_1_s_h_a_r_c_add_instrument_c.html", null ],
          [ "csl::SHARCAddInstrumentV", "classcsl_1_1_s_h_a_r_c_add_instrument_v.html", null ],
          [ "csl::SndFileInstrument0", "classcsl_1_1_snd_file_instrument0.html", null ],
          [ "csl::StringInstrument", "classcsl_1_1_string_instrument.html", null ],
          [ "csl::VAdditiveInstrument", "classcsl_1_1_v_additive_instrument.html", null ]
        ] ],
        [ "csl::KarplusString", "classcsl_1_1_karplus_string.html", null ],
        [ "csl::LineSegment", "classcsl_1_1_line_segment.html", null ],
        [ "csl::Lorenz", "classcsl_1_1_lorenz.html", null ],
        [ "csl::Microphone", "classcsl_1_1_microphone.html", null ],
        [ "csl::Mixer", "classcsl_1_1_mixer.html", null ],
        [ "csl::Noise", "classcsl_1_1_noise.html", null ],
        [ "csl::Oscillator", "classcsl_1_1_oscillator.html", null ],
        [ "csl::RemoteStream", "classcsl_1_1_remote_stream.html", null ],
        [ "csl::RingBufferTap", "classcsl_1_1_ring_buffer_tap.html", null ],
        [ "csl::SimpleSine", "classcsl_1_1_simple_sine.html", null ],
        [ "csl::SineAsPhased", "classcsl_1_1_sine_as_phased.html", null ],
        [ "csl::SineAsScaled", "classcsl_1_1_sine_as_scaled.html", null ],
        [ "csl::SoundCue", "classcsl_1_1_sound_cue.html", null ],
        [ "csl::SoundFontInstrument", "classcsl_1_1_sound_font_instrument.html", null ],
        [ "csl::SpatialPanner", "classcsl_1_1_spatial_panner.html", [
          [ "csl::AmbisonicPanner", "classcsl_1_1_ambisonic_panner.html", null ],
          [ "csl::BinauralPanner", "classcsl_1_1_binaural_panner.html", null ],
          [ "csl::SimplePanner", "classcsl_1_1_simple_panner.html", null ],
          [ "csl::VBAP", "classcsl_1_1_v_b_a_p.html", [
            [ "csl::StereoPanner", "classcsl_1_1_stereo_panner.html", null ],
            [ "csl::SurroundPanner", "classcsl_1_1_surround_panner.html", null ]
          ] ]
        ] ],
        [ "csl::SpatialSource", "classcsl_1_1_spatial_source.html", null ],
        [ "csl::Spatializer", "classcsl_1_1_spatializer.html", [
          [ "csl::Auralizer", "classcsl_1_1_auralizer.html", null ]
        ] ],
        [ "csl::StaticVariable", "classcsl_1_1_static_variable.html", null ],
        [ "csl::Vocoder", "classcsl_1_1_vocoder.html", null ],
        [ "csl::Window", "classcsl_1_1_window.html", [
          [ "csl::BlackmanHarrisWindow", "classcsl_1_1_blackman_harris_window.html", null ],
          [ "csl::BlackmanWindow", "classcsl_1_1_blackman_window.html", null ],
          [ "csl::HammingWindow", "classcsl_1_1_hamming_window.html", null ],
          [ "csl::HannWindow", "classcsl_1_1_hann_window.html", null ],
          [ "csl::RectangularWindow", "classcsl_1_1_rectangular_window.html", null ],
          [ "csl::TriangularWindow", "classcsl_1_1_triangular_window.html", null ],
          [ "csl::WelchWindow", "classcsl_1_1_welch_window.html", null ]
        ] ]
      ] ]
    ] ],
    [ "object", null, [
      [ "CSL6.Accessor", "class_c_s_l6_1_1_accessor.html", null ],
      [ "CSL6.AudioIODevice", "class_c_s_l6_1_1_audio_i_o_device.html", null ],
      [ "CSL6.AudioIODeviceCallback", "class_c_s_l6_1_1_audio_i_o_device_callback.html", [
        [ "CSL6.JUCEIO", "class_c_s_l6_1_1_j_u_c_e_i_o.html", null ]
      ] ],
      [ "CSL6.Buffer", "class_c_s_l6_1_1_buffer.html", [
        [ "CSL6.BufferCMap", "class_c_s_l6_1_1_buffer_c_map.html", null ],
        [ "CSL6.SoundFileBuffer", "class_c_s_l6_1_1_sound_file_buffer.html", null ]
      ] ],
      [ "CSL6.CGestalt", "class_c_s_l6_1_1_c_gestalt.html", null ],
      [ "CSL6.CMIDIMessage", "class_c_s_l6_1_1_c_m_i_d_i_message.html", null ],
      [ "CSL6.CPoint", "class_c_s_l6_1_1_c_point.html", null ],
      [ "CSL6.CThread", "class_c_s_l6_1_1_c_thread.html", null ],
      [ "CSL6.CVariable", "class_c_s_l6_1_1_c_variable.html", [
        [ "CSL6.DynamicVariable", "class_c_s_l6_1_1_dynamic_variable.html", null ],
        [ "CSL6.StaticVariable", "class_c_s_l6_1_1_static_variable.html", null ]
      ] ],
      [ "CSL6.Cacheable", "class_c_s_l6_1_1_cacheable.html", [
        [ "CSL6.CompOrCacheOscillator", "class_c_s_l6_1_1_comp_or_cache_oscillator.html", [
          [ "CSL6.SumOfSines", "class_c_s_l6_1_1_sum_of_sines.html", null ]
        ] ]
      ] ],
      [ "CSL6.Comb", "class_c_s_l6_1_1_comb.html", null ],
      [ "CSL6.Controllable", "class_c_s_l6_1_1_controllable.html", [
        [ "CSL6.Effect", "class_c_s_l6_1_1_effect.html", [
          [ "CSL6.BinaryOp", "class_c_s_l6_1_1_binary_op.html", [
            [ "CSL6.AddOp", "class_c_s_l6_1_1_add_op.html", null ],
            [ "CSL6.MulOp", "class_c_s_l6_1_1_mul_op.html", null ]
          ] ],
          [ "CSL6.Convolver", "class_c_s_l6_1_1_convolver.html", null ],
          [ "CSL6.DelayLine", "class_c_s_l6_1_1_delay_line.html", null ],
          [ "CSL6.DynamicVariable", "class_c_s_l6_1_1_dynamic_variable.html", null ],
          [ "CSL6.FFT", "class_c_s_l6_1_1_f_f_t.html", null ],
          [ "CSL6.FIR", "class_c_s_l6_1_1_f_i_r.html", null ],
          [ "CSL6.FanOut", "class_c_s_l6_1_1_fan_out.html", [
            [ "CSL6.Splitter", "class_c_s_l6_1_1_splitter.html", null ]
          ] ],
          [ "CSL6.Filter", "class_c_s_l6_1_1_filter.html", [
            [ "CSL6.Allpass", "class_c_s_l6_1_1_allpass.html", null ],
            [ "CSL6.Biquad", "class_c_s_l6_1_1_biquad.html", null ],
            [ "CSL6.Butter", "class_c_s_l6_1_1_butter.html", null ],
            [ "CSL6.Formant", "class_c_s_l6_1_1_formant.html", null ],
            [ "CSL6.Moog", "class_c_s_l6_1_1_moog.html", null ],
            [ "CSL6.Notch", "class_c_s_l6_1_1_notch.html", null ]
          ] ],
          [ "CSL6.Freeverb", "class_c_s_l6_1_1_freeverb.html", null ],
          [ "CSL6.InOut", "class_c_s_l6_1_1_in_out.html", null ],
          [ "CSL6.Joiner", "class_c_s_l6_1_1_joiner.html", null ],
          [ "CSL6.Panner", "class_c_s_l6_1_1_panner.html", [
            [ "CSL6.NtoMPanner", "class_c_s_l6_1_1_nto_m_panner.html", null ]
          ] ],
          [ "CSL6.RingBuffer", "class_c_s_l6_1_1_ring_buffer.html", null ],
          [ "CSL6.StereoWidth", "class_c_s_l6_1_1_stereo_width.html", null ],
          [ "CSL6.Stereoverb", "class_c_s_l6_1_1_stereoverb.html", null ]
        ] ],
        [ "CSL6.FrequencyAmount", "class_c_s_l6_1_1_frequency_amount.html", [
          [ "CSL6.Filter", "class_c_s_l6_1_1_filter.html", null ]
        ] ],
        [ "CSL6.Phased", "class_c_s_l6_1_1_phased.html", [
          [ "CSL6.KarplusString", "class_c_s_l6_1_1_karplus_string.html", null ],
          [ "CSL6.Oscillator", "class_c_s_l6_1_1_oscillator.html", [
            [ "CSL6.FSine", "class_c_s_l6_1_1_f_sine.html", null ],
            [ "CSL6.Impulse", "class_c_s_l6_1_1_impulse.html", null ],
            [ "CSL6.Sawtooth", "class_c_s_l6_1_1_sawtooth.html", null ],
            [ "CSL6.Sine", "class_c_s_l6_1_1_sine.html", null ],
            [ "CSL6.Square", "class_c_s_l6_1_1_square.html", null ],
            [ "CSL6.WavetableOscillator", "class_c_s_l6_1_1_wavetable_oscillator.html", [
              [ "CSL6.Abst_SoundFile", "class_c_s_l6_1_1_abst___sound_file.html", null ],
              [ "CSL6.CompOrCacheOscillator", "class_c_s_l6_1_1_comp_or_cache_oscillator.html", null ]
            ] ]
          ] ]
        ] ],
        [ "CSL6.Scalable", "class_c_s_l6_1_1_scalable.html", [
          [ "CSL6.Envelope", "class_c_s_l6_1_1_envelope.html", [
            [ "CSL6.ADSR", "class_c_s_l6_1_1_a_d_s_r.html", null ],
            [ "CSL6.AR", "class_c_s_l6_1_1_a_r.html", null ],
            [ "CSL6.RandEnvelope", "class_c_s_l6_1_1_rand_envelope.html", null ],
            [ "CSL6.Triangle", "class_c_s_l6_1_1_triangle.html", null ]
          ] ],
          [ "CSL6.Filter", "class_c_s_l6_1_1_filter.html", null ],
          [ "CSL6.Freeverb", "class_c_s_l6_1_1_freeverb.html", null ],
          [ "CSL6.KarplusString", "class_c_s_l6_1_1_karplus_string.html", null ],
          [ "CSL6.Mixer", "class_c_s_l6_1_1_mixer.html", null ],
          [ "CSL6.Noise", "class_c_s_l6_1_1_noise.html", [
            [ "CSL6.PinkNoise", "class_c_s_l6_1_1_pink_noise.html", null ],
            [ "CSL6.WhiteNoise", "class_c_s_l6_1_1_white_noise.html", null ]
          ] ],
          [ "CSL6.Oscillator", "class_c_s_l6_1_1_oscillator.html", null ],
          [ "CSL6.Panner", "class_c_s_l6_1_1_panner.html", null ],
          [ "CSL6.RingBuffer", "class_c_s_l6_1_1_ring_buffer.html", null ],
          [ "CSL6.RingBufferTap", "class_c_s_l6_1_1_ring_buffer_tap.html", null ]
        ] ]
      ] ],
      [ "CSL6.FAllpass", "class_c_s_l6_1_1_f_allpass.html", null ],
      [ "CSL6.FilterSpecification", "class_c_s_l6_1_1_filter_specification.html", null ],
      [ "CSL6.IODevice", "class_c_s_l6_1_1_i_o_device.html", null ],
      [ "CSL6.Interleaver", "class_c_s_l6_1_1_interleaver.html", null ],
      [ "CSL6.Model", "class_c_s_l6_1_1_model.html", [
        [ "CSL6.IO", "class_c_s_l6_1_1_i_o.html", [
          [ "CSL6.FileIO", "class_c_s_l6_1_1_file_i_o.html", null ],
          [ "CSL6.JUCEIO", "class_c_s_l6_1_1_j_u_c_e_i_o.html", null ]
        ] ],
        [ "CSL6.MIDIIO", "class_c_s_l6_1_1_m_i_d_i_i_o.html", [
          [ "CSL6.MIDIIn", "class_c_s_l6_1_1_m_i_d_i_in.html", null ],
          [ "CSL6.MIDIOut", "class_c_s_l6_1_1_m_i_d_i_out.html", null ],
          [ "CSL6.MIDIPlayer", "class_c_s_l6_1_1_m_i_d_i_player.html", null ]
        ] ],
        [ "CSL6.UnitGenerator", "class_c_s_l6_1_1_unit_generator.html", [
          [ "CSL6.BlockResizer", "class_c_s_l6_1_1_block_resizer.html", null ],
          [ "CSL6.BufferStream", "class_c_s_l6_1_1_buffer_stream.html", null ],
          [ "CSL6.Effect", "class_c_s_l6_1_1_effect.html", null ],
          [ "CSL6.Envelope", "class_c_s_l6_1_1_envelope.html", null ],
          [ "CSL6.IFFT", "class_c_s_l6_1_1_i_f_f_t.html", null ],
          [ "CSL6.Instrument", "class_c_s_l6_1_1_instrument.html", [
            [ "CSL6.AdditiveInstrument", "class_c_s_l6_1_1_additive_instrument.html", null ],
            [ "CSL6.FMBell", "class_c_s_l6_1_1_f_m_bell.html", null ],
            [ "CSL6.FMInstrument", "class_c_s_l6_1_1_f_m_instrument.html", [
              [ "CSL6.FancyFMInstrument", "class_c_s_l6_1_1_fancy_f_m_instrument.html", null ]
            ] ],
            [ "CSL6.SndFileInstrument0", "class_c_s_l6_1_1_snd_file_instrument0.html", null ],
            [ "CSL6.StringInstrument", "class_c_s_l6_1_1_string_instrument.html", null ],
            [ "CSL6.VAdditiveInstrument", "class_c_s_l6_1_1_v_additive_instrument.html", null ]
          ] ],
          [ "CSL6.KarplusString", "class_c_s_l6_1_1_karplus_string.html", null ],
          [ "CSL6.LineSegment", "class_c_s_l6_1_1_line_segment.html", null ],
          [ "CSL6.Mixer", "class_c_s_l6_1_1_mixer.html", null ],
          [ "CSL6.Noise", "class_c_s_l6_1_1_noise.html", null ],
          [ "CSL6.Oscillator", "class_c_s_l6_1_1_oscillator.html", null ],
          [ "CSL6.RingBufferTap", "class_c_s_l6_1_1_ring_buffer_tap.html", null ],
          [ "CSL6.SoundCue", "class_c_s_l6_1_1_sound_cue.html", null ],
          [ "CSL6.StaticVariable", "class_c_s_l6_1_1_static_variable.html", null ],
          [ "CSL6.Window", "class_c_s_l6_1_1_window.html", [
            [ "CSL6.BlackmanHarrisWindow", "class_c_s_l6_1_1_blackman_harris_window.html", null ],
            [ "CSL6.BlackmanWindow", "class_c_s_l6_1_1_blackman_window.html", null ],
            [ "CSL6.HammingWindow", "class_c_s_l6_1_1_hamming_window.html", null ],
            [ "CSL6.HannWindow", "class_c_s_l6_1_1_hann_window.html", null ],
            [ "CSL6.RectangularWindow", "class_c_s_l6_1_1_rectangular_window.html", null ],
            [ "CSL6.TriangularWindow", "class_c_s_l6_1_1_triangular_window.html", null ],
            [ "CSL6.WelchWindow", "class_c_s_l6_1_1_welch_window.html", null ]
          ] ]
        ] ]
      ] ],
      [ "CSL6.Observer", "class_c_s_l6_1_1_observer.html", null ],
      [ "CSL6.Partial", "class_c_s_l6_1_1_partial.html", null ],
      [ "CSL6.Port", "class_c_s_l6_1_1_port.html", null ],
      [ "CSL6.ReferenceCountedObject", "class_c_s_l6_1_1_reference_counted_object.html", [
        [ "CSL6.MidiDeviceListEntry", "class_c_s_l6_1_1_midi_device_list_entry.html", null ]
      ] ],
      [ "CSL6.SHARCInstrument", "class_c_s_l6_1_1_s_h_a_r_c_instrument.html", null ],
      [ "CSL6.SHARCLibrary", "class_c_s_l6_1_1_s_h_a_r_c_library.html", null ],
      [ "CSL6.SHARCSpectrum", "class_c_s_l6_1_1_s_h_a_r_c_spectrum.html", null ],
      [ "CSL6.Seekable", "class_c_s_l6_1_1_seekable.html", [
        [ "CSL6.Abst_SoundFile", "class_c_s_l6_1_1_abst___sound_file.html", null ],
        [ "CSL6.BufferStream", "class_c_s_l6_1_1_buffer_stream.html", null ],
        [ "CSL6.RingBufferTap", "class_c_s_l6_1_1_ring_buffer_tap.html", null ]
      ] ],
      [ "CSL6.SingleThreadedReferenceCountedObject", "class_c_s_l6_1_1_single_threaded_reference_counted_object.html", null ],
      [ "CSL6.SoundFileMetadata", "class_c_s_l6_1_1_sound_file_metadata.html", null ],
      [ "CSL6.SwigPyIterator", "class_c_s_l6_1_1_swig_py_iterator.html", null ],
      [ "CSL6.Writeable", "class_c_s_l6_1_1_writeable.html", [
        [ "CSL6.Abst_SoundFile", "class_c_s_l6_1_1_abst___sound_file.html", null ],
        [ "CSL6.BufferStream", "class_c_s_l6_1_1_buffer_stream.html", null ],
        [ "CSL6.RingBuffer", "class_c_s_l6_1_1_ring_buffer.html", null ]
      ] ],
      [ "CSL6.testStruct", "class_c_s_l6_1_1test_struct.html", null ]
    ] ],
    [ "csl::Observer", "classcsl_1_1_observer.html", [
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", null ],
      [ "csl::SpatialPanner", "classcsl_1_1_spatial_panner.html", null ],
      [ "csl::Spatializer", "classcsl_1_1_spatializer.html", null ]
    ] ],
    [ "Orbit", "class_orbit.html", null ],
    [ "csl::Partial", "structcsl_1_1_partial.html", null ],
    [ "SFZero::SF2::pbag", "struct_s_f_zero_1_1_s_f2_1_1pbag.html", null ],
    [ "SFZero::SF2::pgen", "struct_s_f_zero_1_1_s_f2_1_1pgen.html", null ],
    [ "SFZero::SF2::phdr", "struct_s_f_zero_1_1_s_f2_1_1phdr.html", null ],
    [ "PME", "class_p_m_e.html", null ],
    [ "PMESource", "class_p_m_e_source.html", null ],
    [ "SFZero::SF2::pmod", "struct_s_f_zero_1_1_s_f2_1_1pmod.html", null ],
    [ "csl::Port", "classcsl_1_1_port.html", null ],
    [ "SFZero::SF2Sound::Preset", "struct_s_f_zero_1_1_s_f2_sound_1_1_preset.html", null ],
    [ "PresetComparator", "class_preset_comparator.html", null ],
    [ "Processor", null, [
      [ "csl::DLine", "classcsl_1_1_d_line.html", null ]
    ] ],
    [ "SFZero::SF2::rangesType", "struct_s_f_zero_1_1_s_f2_1_1ranges_type.html", null ],
    [ "juce::ReferenceCountedObject", null, [
      [ "csl::MidiDeviceListEntry", "structcsl_1_1_midi_device_list_entry.html", null ]
    ] ],
    [ "SFZero::RIFFChunk", "struct_s_f_zero_1_1_r_i_f_f_chunk.html", null ],
    [ "csl::Seekable", "classcsl_1_1_seekable.html", [
      [ "csl::Abst_SoundFile", "classcsl_1_1_abst___sound_file.html", null ],
      [ "csl::BufferStream", "classcsl_1_1_buffer_stream.html", null ],
      [ "csl::RingBufferTap", "classcsl_1_1_ring_buffer_tap.html", null ]
    ] ],
    [ "SFZero::SF2Generator", "struct_s_f_zero_1_1_s_f2_generator.html", null ],
    [ "SFZero::SF2Reader", "class_s_f_zero_1_1_s_f2_reader.html", null ],
    [ "SFZero::SFZEG", "class_s_f_zero_1_1_s_f_z_e_g.html", null ],
    [ "SFZero::SFZEGParameters", "struct_s_f_zero_1_1_s_f_z_e_g_parameters.html", null ],
    [ "SFZero::SFZReader", "class_s_f_zero_1_1_s_f_z_reader.html", null ],
    [ "SFZero::SFZRegion", "class_s_f_zero_1_1_s_f_z_region.html", null ],
    [ "SFZero::SFZSample", "class_s_f_zero_1_1_s_f_z_sample.html", null ],
    [ "csl::SHARCInstrument", "classcsl_1_1_s_h_a_r_c_instrument.html", null ],
    [ "csl::SHARCLibrary", "classcsl_1_1_s_h_a_r_c_library.html", null ],
    [ "csl::SHARCSpectrum", "classcsl_1_1_s_h_a_r_c_spectrum.html", null ],
    [ "SFZero::SF2::shdr", "struct_s_f_zero_1_1_s_f2_1_1shdr.html", null ],
    [ "csl::ShoeBox", "classcsl_1_1_shoe_box.html", null ],
    [ "SliderListener", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", null ],
      [ "CSLServerComponent", "class_c_s_l_server_component.html", null ]
    ] ],
    [ "Socket", "class_socket.html", [
      [ "CommunicatingSocket", "class_communicating_socket.html", [
        [ "TCPSocket", "class_t_c_p_socket.html", null ],
        [ "UDPSocket", "class_u_d_p_socket.html", null ]
      ] ],
      [ "TCPServerSocket", "class_t_c_p_server_socket.html", null ]
    ] ],
    [ "csl::SoundFileMetadata", "classcsl_1_1_sound_file_metadata.html", null ],
    [ "csl::Speaker", "classcsl_1_1_speaker.html", null ],
    [ "csl::SpeakerLayoutExpert", "classcsl_1_1_speaker_layout_expert.html", null ],
    [ "csl::SpeakerSet", "classcsl_1_1_speaker_set.html", null ],
    [ "csl::SpeakerSetLayout", "classcsl_1_1_speaker_set_layout.html", null ],
    [ "swig::stop_iteration", "structswig_1_1stop__iteration.html", null ],
    [ "SFZero::StringSlice", "class_s_f_zero_1_1_string_slice.html", null ],
    [ "swig_cast_info", "structswig__cast__info.html", null ],
    [ "swig_const_info", "structswig__const__info.html", null ],
    [ "swig_globalvar", "structswig__globalvar.html", null ],
    [ "swig_module_info", "structswig__module__info.html", null ],
    [ "swig_type_info", "structswig__type__info.html", null ],
    [ "swig_varlinkobject", "structswig__varlinkobject.html", null ],
    [ "swig::SwigPtr_PyObject", "classswig_1_1_swig_ptr___py_object.html", [
      [ "swig::SwigVar_PyObject", "structswig_1_1_swig_var___py_object.html", null ]
    ] ],
    [ "SwigPyClientData", "struct_swig_py_client_data.html", null ],
    [ "swig::SwigPyIterator", "structswig_1_1_swig_py_iterator.html", null ],
    [ "SwigPyObject", "struct_swig_py_object.html", null ],
    [ "SwigPyPacked", "struct_swig_py_packed.html", null ],
    [ "csl::Synch", "classcsl_1_1_synch.html", [
      [ "csl::SynchPthread", "classcsl_1_1_synch_pthread.html", null ]
    ] ],
    [ "juce::Synthesiser", null, [
      [ "SFZero::SFZSynth", "class_s_f_zero_1_1_s_f_z_synth.html", null ]
    ] ],
    [ "juce::SynthesiserSound", null, [
      [ "SFZero::SFZSound", "class_s_f_zero_1_1_s_f_z_sound.html", [
        [ "SFZero::SF2Sound", "class_s_f_zero_1_1_s_f2_sound.html", null ]
      ] ]
    ] ],
    [ "juce::SynthesiserVoice", null, [
      [ "SFZero::SFZVoice", "class_s_f_zero_1_1_s_f_z_voice.html", null ]
    ] ],
    [ "csl::testStruct", "structcsl_1_1test_struct.html", null ],
    [ "juce::Thread", null, [
      [ "GThread", "class_g_thread.html", null ],
      [ "LThread", "class_l_thread.html", null ]
    ] ],
    [ "juce::Timer", null, [
      [ "AudioWaveformDisplay", "class_audio_waveform_display.html", null ],
      [ "CSLAbstComponent", "class_c_s_l_abst_component.html", null ],
      [ "VUMeter", "class_v_u_meter.html", null ],
      [ "csl::MIDIIO", "classcsl_1_1_m_i_d_i_i_o.html", null ]
    ] ],
    [ "Timer", null, [
      [ "CSLComponent", "class_c_s_l_component.html", null ],
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", null ],
      [ "CSLServerComponent", "class_c_s_l_server_component.html", null ]
    ] ],
    [ "FFTReal::TrigoLUT", "class_f_f_t_real_1_1_trigo_l_u_t.html", null ],
    [ "type", null, [
      [ "CSL6._SwigNonDynamicMeta", "class_c_s_l6_1_1___swig_non_dynamic_meta.html", null ]
    ] ],
    [ "csl::VBAPSourceCache", "classcsl_1_1_v_b_a_p_source_cache.html", null ],
    [ "csl::Writeable", "classcsl_1_1_writeable.html", [
      [ "csl::Abst_SoundFile", "classcsl_1_1_abst___sound_file.html", null ],
      [ "csl::BufferStream", "classcsl_1_1_buffer_stream.html", null ],
      [ "csl::RingBuffer", "classcsl_1_1_ring_buffer.html", null ]
    ] ]
];